package dev.game.entities.ship;

import dev.game.Handler;
import dev.game.entities.Entity;
import dev.game.entities.EntityManager;
import dev.game.entities.ID;
import dev.game.entities.battleentity.BattleField;
import dev.game.entities.combattroop.PlayerTroop;
import dev.game.gfx.Animation;
import dev.game.gfx.Asset;
import dev.game.inventory.Inventory;
import dev.game.item.Armor;
import dev.game.item.Weapon;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class PlayerShip extends Ship {
	public static final long DEFAULT_ATTACK_COOLDOWN = 1000;

	private Animation animDown, animUp, animLeft, animRight;
	private EntityManager entitymanager;
	private PlayerTroop troop;
	private Inventory inventory;
	private Weapon weapon;
	private Armor armor;
	private long attackCooldown;
	private boolean inBattle;

	public PlayerShip(EntityManager entitymanager, Handler handler, float x, float y, ID id) {
		super(entitymanager, handler, x, y, Ship.DEFAULT_CREATURE_WIDTH, Ship.DEFAULT_CREATURE_HEIGHT, id);
		this.entitymanager = entitymanager;

		bounds.x = 5;
		bounds.y = 10;
		bounds.height = 25;
		bounds.width = 35;

		setMaxhealth(DEFAULT_MAX_HEALTH);
		setHealth(DEFAULT_HEALTH);
		setAtk(DEFAULT_ATTACK);
		setDef(DEFAULT_DEFENCE);
		setSpeed(DEFAULT_SPEED);
		setBspeed(DEFAULT_BULLET_SPEED);
		setAttackCooldown(DEFAULT_ATTACK_COOLDOWN);
		inBattle = false;

		animDown = new Animation(500, Asset.player_down);
		animUp = new Animation(500, Asset.player_up);
		animLeft = new Animation(500, Asset.player_left);
		animRight = new Animation(500, Asset.player_right);

		inventory = new Inventory(handler);
		weapon = null;
		armor = null;
	}

	@Override
	public void tick() {
		if (inBattle)
			return;
		inventory.tick();

		if (inventory.isActive())
			return;

		animDown.tick();
		animUp.tick();
		animRight.tick();
		animLeft.tick();

		getInput();
		move();
		handler.getGameCamera().centerOnEntity(this);

		Entity e = checkEntityCollisions(0f, 0f);
		if (e != null && e.getID() == ID.Enemy) {
			troop = new PlayerTroop(this, entitymanager, handler, 300, 500, ID.PlayerTroop);
			EnemyShip ex = (EnemyShip) e;
			entitymanager.addEntity(new BattleField(entitymanager, handler, ID.Menu, troop, ex.getEtroop()));
			inBattle = true;
		}
	}

	private void getInput() {
		xMove = 0;
		yMove = 0;

		if (inventory.isActive())
			return;

		if (handler.getKeyManager().up) {
			yMove = -speed;
		}
		if (handler.getKeyManager().down) {
			yMove = speed;
		}
		if (handler.getKeyManager().left) {
			xMove = -speed;
		}
		if (handler.getKeyManager().right) {
			xMove = speed;
		}
	}

	@Override
	public void render(Graphics g) {
		g.drawImage(getCurrentAnimationFrame(), (int) (x - handler.getGameCamera().getxOffset()),
				(int) (y - handler.getGameCamera().getyOffset()), width, height, null);

	}

	public void postRender(Graphics g) {
		inventory.render(g);
	}

	private BufferedImage getCurrentAnimationFrame() {
		if (xMove < 0) {
			return animLeft.getCurrentFrame();
		} else if (xMove > 0) {
			return animRight.getCurrentFrame();
		} else if (yMove < 0) {
			return animUp.getCurrentFrame();
		} else {
			return animDown.getCurrentFrame();
		}
	}

	@Override
	public void die() {
	}

	public Inventory getInventory() {
		return inventory;
	}

	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}

	public void equipWeapon(Weapon a) {
		if (weapon == a) {
			takeOffWeaponStat(weapon);
			weapon.setEquiped(false);
			weapon = null;
			return;
		}
		if (weapon != null) {
			weapon.setEquiped(false);
			takeOffWeaponStat(weapon);
		}
		weapon = a;
		weapon.setEquiped(true);
		equipWeaponStat(a);

	}

	public void equipWeaponStat(Weapon a) {
		atk += a.getAtk();
		bspeed = a.getBSpeed();
		attackCooldown = a.getACD();

	}

	public void takeOffWeaponStat(Weapon a) {
		atk -= a.getAtk();
		setBspeed(DEFAULT_BULLET_SPEED);
		setAttackCooldown(DEFAULT_ATTACK_COOLDOWN);
	}

	public void equipArmor(Armor a) {
		if (armor == a) {
			takeOffArmorStat(armor);
			armor.setEquiped(false);
			armor = null;
			return;
		}
		if (armor != null) {
			armor.setEquiped(false);
			takeOffArmorStat(armor);
		}
		armor = a;
		armor.setEquiped(true);
		equipArmorStat(a);
	}

	public void equipArmorStat(Armor a) {
		int healthPercentage = health * 1000 / maxhealth;
		maxhealth += a.getHealth();
		health = healthPercentage * maxhealth / 1000;
		def -= a.getDefence();
	}

	public void takeOffArmorStat(Armor a) {
		int healthPercentage = health * 1000 / maxhealth;
		maxhealth -= a.getHealth();
		setHealth(healthPercentage * maxhealth / 1000);
		def -= a.getDefence();
	}

	// GETTER SETTER

	public Weapon getWeapon() {
		return weapon;
	}

	public void setWeapon(Weapon weapon) {
		this.weapon = weapon;
	}

	public Armor getArmor() {
		return armor;
	}

	public void setArmor(Armor armor) {
		this.armor = armor;
	}

	public long getAttackCooldown() {
		return attackCooldown;
	}

	public void setAttackCooldown(long attackCooldown) {
		this.attackCooldown = attackCooldown;
	}

	public boolean isInBattle() {
		return inBattle;
	}

	public void setInBattle(boolean inBattle) {
		this.inBattle = inBattle;
	}

}
