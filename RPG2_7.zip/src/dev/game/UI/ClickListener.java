//
package dev.game.UI;

public interface ClickListener {
    public void onClick();
}
