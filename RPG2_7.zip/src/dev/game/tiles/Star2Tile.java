package dev.game.tiles;

import dev.game.gfx.Asset;

public class Star2Tile extends Tile {

    public Star2Tile(int id) {
        super(Asset.star2, id);
    }
}
