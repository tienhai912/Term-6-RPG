package dev.game.tiles;

import dev.game.gfx.Asset;

public class Star3Tile extends Tile {

    public Star3Tile(int id) {
        super(Asset.star3, id);
    }
}
