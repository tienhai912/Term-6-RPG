package dev.game.tiles;

import dev.game.gfx.Asset;

public class Star1Tile extends Tile {

    public Star1Tile(int id) {
        super(Asset.star1, id);
    }
}
