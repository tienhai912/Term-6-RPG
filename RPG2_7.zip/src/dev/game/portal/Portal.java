package dev.game.portal;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import dev.game.Handler;
import dev.game.entities.Entity;
import dev.game.entities.ID;
import dev.game.entities.ship.PlayerShip;
import dev.game.gfx.Asset;
import dev.game.state.GameState;
import dev.game.state.State;
import dev.game.worlds.World;

public class Portal extends Entity {
	public static Portal portalD = new Portal(Asset.coin, 0,0,ID.PortalD);
	
	public static final int PORTALWIDTH = 40, PORTALHEIGHT = 40;
	protected BufferedImage texture;


	public Portal(BufferedImage texture, float x, float y, ID id) {
		super(null, x, y, PORTALWIDTH, PORTALHEIGHT, id);
		this.texture = texture;
		bounds=new Rectangle((int)x, (int)y, PORTALWIDTH, PORTALHEIGHT);
	}

	public void tick() {
		if (handler == null) {
			return;
		}
		if (getPlayerShip().getCollisionBounds(0f, 0f).intersects(bounds)) {
			if (handler.getKeyManager().keyJustPressed(KeyEvent.VK_ENTER)) {
				
			}
		}
	}

	public void render(Graphics g) {
		if (handler == null) {
			return;
		}
		g.drawImage(texture, (int) (x - handler.getGameCamera().getxOffset()),
				(int) (y - handler.getGameCamera().getyOffset()), PORTALWIDTH, PORTALHEIGHT, null);
	}

	public void die() {
		active = false;
	}

	public PlayerShip getPlayerShip() {
		PlayerShip ex = null;
		for (Entity e : handler.getWorld().getEntityManager().getEntities()) {
			if (e.getID() == ID.Player) {
				ex = (PlayerShip) e;
				break;
			}
		}
		return ex;
	}
	
	public Portal createNew(Handler handler, int x1, int y1){
		Portal newPortal = new Portal(texture,x1,y1,id);
		newPortal.handler = handler;
		return newPortal;
	}

	// GETTER SETTER
	public void setPosition(int x, int y) {
		this.x = x;
		this.y = y;
		bounds.x = x;
		bounds.y = y;
	}

	public Handler getHandler() {
		return handler;
	}

	public void setHandler(Handler handler) {
		this.handler = handler;
	}

	public BufferedImage getTexture() {
		return texture;
	}

	public void setTexture(BufferedImage texture) {
		this.texture = texture;
	}
	
}
