package dev.game.inventory;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import dev.game.Handler;
import dev.game.entities.ship.PlayerShip;
import dev.game.gfx.Asset;
import dev.game.gfx.Text;
import dev.game.item.Armor;
import dev.game.item.Item;
import dev.game.item.Misc;
import dev.game.item.Weapon;

public class Inventory {

	private Handler handler;
	private boolean active = false;
	private ArrayList<Item> inventoryItems;

	private int invX = 64, invY = 32, invWidth = 768, invHeight = 576, invListCenterX = invX + 256,
			invListCenterY = invY + invHeight / 2 + 7, invListSpacing = 45;

	private int invImageX = 636, invImageY = 72, invImageWidth = 116, InvImageHeight = 116;

	private int invAmountX = 694, invAmountY = 220;

	private int invStat1X = 694, invStat1Y = 328;
	private int invStat2X = 694, invStat2Y = 388;
	private int invStat3X = 694, invStat3Y = 448;
	private int invStat4X = 694, invStat4Y = 508;

	private int selectedItem = 0;

	public Inventory(Handler handler) {
		this.handler = handler;
		inventoryItems = new ArrayList<Item>();

	}

	public void tick() {
		if (handler.getKeyManager().keyJustPressed(KeyEvent.VK_E)) {
			active = !active;
		}
		if (!active) {
			return;
		}

		if (handler.getKeyManager().keyJustPressed(KeyEvent.VK_UP)) {
			selectedItem--;
		}
		if (handler.getKeyManager().keyJustPressed(KeyEvent.VK_DOWN)) {
			selectedItem++;
		}
		if (handler.getKeyManager().keyJustPressed(KeyEvent.VK_ENTER)) {
			Item item = inventoryItems.get(selectedItem);
			PlayerShip playerShip = item.getPlayerShip();
			if (isWeapon(item)) {
				Weapon weapon = (Weapon) item;
				playerShip.equipWeapon(weapon);

			} else if (isArmor(item)) {
				Armor armor = (Armor) item;
				playerShip.equipArmor(armor);
			} else if (isConsumable(item)) {
				Misc misc = (Misc) item;
				if (isAttackUp(item)) {
					playerShip.setAtk(playerShip.getAtk() + misc.getStat());
				} else if (isDefenceUp(item)) {
					playerShip.setDef(playerShip.getDef() + (float) misc.getStat() / 100);
				} else if (isHealthUp(item)) {
					playerShip.setMaxhealth(playerShip.getMaxhealth() + misc.getStat());
				} else if (isPotion(item)) {
					int newHealth = playerShip.getHealth() + misc.getStat() * playerShip.getMaxhealth() / 100;
					if (newHealth > playerShip.getMaxhealth())
						newHealth = playerShip.getMaxhealth();
					playerShip.setHealth(newHealth);
				}
				removeItem(item);
				sortItem();
			}

		}

		if (selectedItem < 0) {
			selectedItem = inventoryItems.size() - 1;
		} else if (selectedItem >= inventoryItems.size()) {
			selectedItem = 0;
		}

	}

	public void render(Graphics g) {
		if (!active) {
			return;
		}
		g.drawImage(Asset.inventoryScreen, invX, invY, invWidth, invHeight, null);

		int len = inventoryItems.size();
		if (len == 0) {
			return;
		}

		for (int i = -5; i < 6; i++) {
			if (selectedItem + i < 0 || selectedItem + i >= len) {
				continue;
			}
			Item itemI = inventoryItems.get(selectedItem + i);
			if (itemI.getItemNum() >= 10 && itemI.getItemNum() < 20) {
				Weapon weaponI = (Weapon) itemI;
				if (weaponI.isEquiped()) {
					Text.drawString(g, " > " + itemI.getName() + " < ", invListCenterX,
							invListCenterY + i * invListSpacing, true, Color.RED, Asset.font36);
					continue;
				}
			} else if (itemI.getItemNum() >= 20 && itemI.getItemNum() < 30) {
				Armor armorI = (Armor) itemI;
				if (armorI.isEquiped()) {
					Text.drawString(g, " > " + itemI.getName() + " < ", invListCenterX,
							invListCenterY + i * invListSpacing, true, Color.RED, Asset.font36);
					continue;
				}
			}

			if (i == 0) {
				Text.drawString(g, " > " + itemI.getName() + " < ", invListCenterX, invListCenterY + i * invListSpacing,
						true, Color.YELLOW, Asset.font36);
			} else {
				Text.drawString(g, itemI.getName(), invListCenterX, invListCenterY + i * invListSpacing, true,
						Color.WHITE, Asset.font36);
			}
		}

		Item item = inventoryItems.get(selectedItem);
		g.drawImage(item.getTexture(), invImageX, invImageY, invImageWidth, InvImageHeight, null);
		Text.drawString(g, Integer.toString(item.getAmount()), invAmountX, invAmountY, true, Color.decode("#835AF1"),
				Asset.font36);

		if (isWeapon(item)) {
			Weapon weapon = (Weapon) item;
			Text.drawString(g, "Atk : " + Integer.toString(weapon.getAtk()), invStat1X, invStat1Y, true,
					Color.decode("#835AF1"), Asset.font36);
			Text.drawString(g, "BSpd : " + Integer.toString(weapon.getBSpeed()), invStat2X, invStat2Y, true,
					Color.decode("#835AF1"), Asset.font36);
			Text.drawString(g, "ACD : " + Long.toString(weapon.getACD()), invStat3X, invStat3Y, true,
					Color.decode("#835AF1"), Asset.font36);
			Text.drawString(g, Integer.toString(weapon.getPrice()) + "$", invStat4X, invStat4Y, true,
					Color.decode("#835AF1"), Asset.font36);

		} else if (isArmor(item)) {
			Armor armor = (Armor) item;
			Text.drawString(g, "HP : " + Integer.toString(armor.getHealth()), invStat1X, invStat1Y, true,
					Color.decode("#835AF1"), Asset.font36);
			Text.drawString(g, "Def : " + Float.toString(armor.getDefence()), invStat2X, invStat2Y, true,
					Color.decode("#835AF1"), Asset.font36);

		} else if (isConsumable(item)) {
			Misc misc = (Misc) item;
			if (isAttackUp(item)) {
				Text.drawString(g, "Atk+ : " + Integer.toString(misc.getStat()), invStat1X, invStat1Y, true,
						Color.decode("#835AF1"), Asset.font36);
			} else if (isDefenceUp(item)) {
				Text.drawString(g, "Def+ : " + Float.toString((float) misc.getStat() / 100), invStat1X, invStat1Y, true,
						Color.decode("#835AF1"), Asset.font36);
			} else if (isHealthUp(item)) {
				Text.drawString(g, "HP+ : " + Integer.toString(misc.getStat()), invStat1X, invStat1Y, true,
						Color.decode("#835AF1"), Asset.font36);
			} else if (isPotion(item)) {
				Text.drawString(g, "HP : " + Integer.toString(misc.getStat()) + "%", invStat1X, invStat1Y, true,
						Color.decode("#835AF1"), Asset.font36);
			}
		}
		Text.drawString(g, Integer.toString(item.getPrice()) + "$", invStat4X, invStat4Y, true, Color.decode("#835AF1"),
				Asset.font36);
	}

	// Methods
	public void addItem(Item item) {
		for (Item i : inventoryItems) {
			if (i.getItemNum() == item.getItemNum()) {
				i.setAmount(i.getAmount() + item.getAmount());
				return;
			}

		}
		inventoryItems.add(item);
	}
	
	public void removeItem(Item item) {
		for (Item i : inventoryItems) {
			if (i.getItemNum() == item.getItemNum()) {
				i.setAmount(i.getAmount() - 1);
				if(i.getAmount() ==0) inventoryItems.remove(item);
				return;
			}

		}
		
	}

	public boolean isWeapon(Item item) {
		if (item.getItemNum() >= 10 && item.getItemNum() < 20)
			return true;
		else
			return false;
	}

	public boolean isArmor(Item item) {
		if (item.getItemNum() >= 20 && item.getItemNum() < 30)
			return true;
		else
			return false;
	}

	public boolean isConsumable(Item item) {
		if (item.getItemNum() >= 30 && item.getItemNum() < 70)
			return true;
		else
			return false;
	}

	public boolean isAttackUp(Item item) {
		if (item.getItemNum() >= 30 && item.getItemNum() < 40)
			return true;
		else
			return false;
	}

	public boolean isDefenceUp(Item item) {
		if (item.getItemNum() >= 40 && item.getItemNum() < 50)
			return true;
		else
			return false;
	}

	public boolean isHealthUp(Item item) {
		if (item.getItemNum() >= 50 && item.getItemNum() < 60)
			return true;
		else
			return false;
	}

	public boolean isPotion(Item item) {
		if (item.getItemNum() >= 60 && item.getItemNum() < 70)
			return true;
		else
			return false;
	}

	public void sortItem() {
		Collections.sort(inventoryItems, new Comparator<Item>() {
			@Override
			public int compare(Item arg0, Item arg1) {
				if (arg0.getItemNum() > arg1.getItemNum())
					return 1;
				else if (arg0.getItemNum() < arg1.getItemNum())
					return -1;
				else
					return 0;
			}
		});
	}

	// GETTER SETTER
	public Handler getHandler() {
		return handler;
	}

	public void setHandler(Handler handler) {
		this.handler = handler;
	}

	public boolean isActive() {
		return active;
	}

}
