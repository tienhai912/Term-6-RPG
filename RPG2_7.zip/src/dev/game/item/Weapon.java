package dev.game.item;


import java.awt.image.BufferedImage;

import dev.game.gfx.Asset;

public class Weapon extends Item {
	private int atk;
	private int bSpeed;
	private long ACD;
	
	private boolean isEquiped;
	
	 public static Weapon photonCannon;

	public Weapon(BufferedImage texture, String name, int itemNum) {
		super(texture, name, itemNum);
		isEquiped = false;
	}
	
	public Weapon(BufferedImage texture, String name, int itemNum, int atk, int bSpeed, long ACD, int price) {
		this(texture, name, itemNum);
		setStat(atk,bSpeed,ACD);
		setPrice(price);
	}

	public void setStat(int atk, int bSpeed, long ACD) {
		this.atk = atk;
		this.bSpeed = bSpeed;
		this.ACD = ACD;
	}
	
	public Item createNew(int amount) {
        Item newItem = new Weapon(texture, name, itemNum);
        newItem.setActive(true);
        newItem.setAmount(amount);
        return newItem;
    }

    public Item createNew(int x, int y) {
        Item newItem = new Weapon(texture, name, itemNum);
        newItem.setPosition(x, y);
        return newItem;
    }
    
    public Item createNew(int x, int y, int amount) {
		Item newItem = new Weapon(texture, name, itemNum, atk, bSpeed, ACD, getPrice());
		newItem.setPosition(x, y);
		newItem.setActive(true);
		newItem.setAmount(amount);
		return newItem;
	}
    
    public static void createWeapon(){
    	photonCannon = new Weapon(Asset.cannon1, "Photon Cannon", 10, 100, 10, 500, 1000);
    }
	
	// GETTER SETTER

	public int getAtk() {
		return atk;
	}

	public void setAtk(int atk) {
		this.atk = atk;
	}

	public int getBSpeed() {
		return bSpeed;
	}

	public void setBSpeed(int bSpeed) {
		this.bSpeed = bSpeed;
	}

	public boolean isEquiped() {
		return isEquiped;
	}

	public void setEquiped(boolean isEquiped) {
		this.isEquiped = isEquiped;
	}

	public long getACD() {
		return ACD;
	}

	public void setACD(long ACD) {
		this.ACD = ACD;
	}
	
}
