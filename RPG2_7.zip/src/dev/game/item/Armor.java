package dev.game.item;

import java.awt.image.BufferedImage;

import dev.game.gfx.Asset;

public class Armor extends Item {
	private int health;
	private float defence;
	private int price;
	private boolean isEquiped;
	
	 public static Armor ironShield = new Armor(Asset.defenceUp, "Iron Shield", 20, 1000, 0.1F, 1000);
	 public static Armor ironShield1 = new Armor(Asset.defenceUp, "Iron Shield", 21, 1000, 0.1F, 1000);

	public Armor(BufferedImage texture, String name, int itemNum) {
		super(texture, name, itemNum);
		isEquiped = false;
	}
	
	public Armor(BufferedImage texture, String name, int itemNum, int health, float defence, int price) {
		this(texture, name, itemNum);
		setStat(health,defence);
		setPrice(price);
	}

	public void setStat(int health, float defence) {
		this.health = health;
		this.defence = defence;
	}
	public Item createNew(int amount) {
        Item newItem = new Armor(texture, name, itemNum);
        newItem.setActive(true);
        newItem.setAmount(amount);
        return newItem;
    }

    public Item createNew(int x, int y) {
        Item newItem = new Armor(texture, name, itemNum);
        newItem.setPosition(x, y);
        return newItem;
    }
    
    public Item createNew(int x, int y, int amount) {
		Item newItem = new Armor(texture, name, itemNum, health, defence, price);
		newItem.setPosition(x, y);
		newItem.setActive(true);
		newItem.setAmount(amount);
		return newItem;
	}
	
	// GETTER SETTER

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public float getDefence() {
		return defence;
	}

	public void setDefence(int defence) {
		this.defence = defence;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public boolean isEquiped() {
		return isEquiped;
	}

	public void setEquiped(boolean isEquiped) {
		this.isEquiped = isEquiped;
	}
	


}
