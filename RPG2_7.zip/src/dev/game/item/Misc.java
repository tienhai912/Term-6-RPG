package dev.game.item;

import java.awt.image.BufferedImage;

import dev.game.gfx.Asset;

public class Misc extends Item {
	public static Misc coin1000, attackUp, defenceUp, healthUp, potion10;

	private int stat;

	public Misc(BufferedImage texture, String name, int itemNum) {
		super(texture, name, itemNum);

	}

	public Misc(BufferedImage texture, String name, int itemNum, int stat, int price) {
		this(texture, name, itemNum);
		setStat(stat);
		setPrice(price);

	}

	public Item createNew(int amount) {
		Item newItem = new Misc(texture, name, itemNum);
		newItem.setActive(true);
		newItem.setAmount(amount);
		return newItem;
	}

	public Item createNew(int x, int y) {
		Item newItem = new Misc(texture, name, itemNum);
		newItem.setPosition(x, y);
		return newItem;
	}

	public Item createNew(int x, int y, int amount) {
		Item newItem = new Misc(texture, name, itemNum, stat, getPrice());
		newItem.setPosition(x, y);
		newItem.setActive(true);
		newItem.setAmount(amount);
		return newItem;
	}

	public static void createMisc() {
		coin1000 = new Misc(Asset.coin, "Coin", 0, 0, 1000);
		attackUp = new Misc(Asset.attackUp, "Attack Up", 30, 10, 1000);
		defenceUp = new Misc(Asset.defenceUp, "Defence Up", 40, 5, 2000);
		healthUp = new Misc(Asset.healthUp, "Health Up", 50, 200, 2000);
		potion10 = new Misc(Asset.potion, "Potion", 60, 10, 1000);
	}

	// GETTER SETTER

	public int getStat() {
		return stat;
	}

	public void setStat(int stat) {
		this.stat = stat;
	}

}
