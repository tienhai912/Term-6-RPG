package dev.game.item;

import java.awt.image.BufferedImage;

import dev.game.gfx.Asset;

public class Misc extends Item {
	public static Misc attackUp = new Misc(Asset.attackUp, "attackUp", 0);
    public static Misc defenceUp = new Misc(Asset.defenceUp, "defenceUp", 1);
    public static Misc healthUp = new Misc(Asset.healthUp, "healthUp", 2);
    public static Misc speedUp = new Misc(Asset.speedUp, "speedUp", 3);
	
	public Misc(BufferedImage texture, String name, int itemNum){
		super(texture, name, itemNum);
	}
	
	public Item createNew(int amount) {
        Item newItem = new Misc(texture, name, itemNum);
        newItem.setActive(true);
        newItem.setAmount(amount);
        return newItem;
    }

    public Item createNew(int x, int y) {
        Item newItem = new Misc(texture, name, itemNum);
        newItem.setPosition(x, y);
        return newItem;
    }
    
    public Item createNew(int x, int y, int amount) {
		Item newItem = new Misc(texture, name, itemNum);
		newItem.setPosition(x, y);
		newItem.setActive(true);
		newItem.setAmount(amount);
		return newItem;
	}
}
