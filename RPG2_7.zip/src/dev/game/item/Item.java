package dev.game.item;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

import dev.game.Handler;
import dev.game.entities.Entity;
import dev.game.entities.ID;
import dev.game.entities.ship.PlayerShip;

public abstract class Item extends Entity {

	public static Item[] items = new Item[256];

	public static final int ITEMWIDTH = 40, ITEMHEIGHT = 40;
	protected BufferedImage texture;
	protected String name;
	protected final int itemNum;
	private int price;
	protected int x1, y1, amount;

	public Item(BufferedImage texture, String name, int itemNum) {
		super(null, 0, 0, ITEMWIDTH, ITEMHEIGHT, ID.Item);
		this.texture = texture;
		this.name = name;
		this.itemNum = itemNum;
		amount = 1;

		items[itemNum] = this;

		bounds = new Rectangle(x1, y1, ITEMWIDTH, ITEMHEIGHT);
	}

	public void tick() {
		if (handler == null) {
			return;
		}
		if (getPlayerShip().getCollisionBounds(0f, 0f).intersects(bounds)) {
			active = false;
			getPlayerShip().getInventory().addItem(this);
			getPlayerShip().getInventory().sortItem();
		}
	}

	public void render(Graphics g) {
		if (handler == null) {
			return;
		}
		g.drawImage(texture, (int) (x - handler.getGameCamera().getxOffset()),
				(int) (y - handler.getGameCamera().getyOffset()), ITEMWIDTH, ITEMHEIGHT, null);
	}

	public void die() {
		active = false;
	}

	public PlayerShip getPlayerShip() {
		PlayerShip ex = null;
		for (Entity e : handler.getWorld().getEntityManager().getEntities()) {
			if (e.getID() == ID.Player) {
				ex = (PlayerShip) e;
				break;
			}
		}
		return ex;
	}

	// GETTER SETTER
	public void setPosition(int x, int y) {
		this.x = x;
		this.y = y;
		bounds.x = x;
		bounds.y = y;
	}

	public Handler getHandler() {
		return handler;
	}

	public void setHandler(Handler handler) {
		this.handler = handler;
	}

	public BufferedImage getTexture() {
		return texture;
	}

	public void setTexture(BufferedImage texture) {
		this.texture = texture;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getX1() {
		return x1;
	}

	public void setX1(int x) {
		this.x1 = x;
	}

	public int getY1() {
		return y1;
	}

	public void setY1(int y) {
		this.y1 = y;
	}

	public int getItemNum() {
		return itemNum;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}
